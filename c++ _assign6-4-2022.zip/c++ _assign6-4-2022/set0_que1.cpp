#include<iostream>
#include<vector>
#include <bits/stdc++.h>
using namespace std;

int main()
{
    vector<string> v1={"virendra","Sachin", "Saurav", "Rahul", "Laxman"};
    vector<string> v2={"Harbhajan", "Ashish", "Rahul", "Yuvraj", "Saurav"};
    vector<string> v3(10);

    sort(v1.begin(),v1.end());
    sort(v2.begin(),v2.end());
   
    
    merge(v1.begin(),v1.end(),v2.begin(),v2.end(),v3.begin());
    
    
    cout <<endl;
    
    v3.erase(std::unique(v3.begin(), v3.end()), v3.end());
    
    for(int i=0;i<v3.size();i++)
    {
        cout << v3[i]<< " ";
    }
}
